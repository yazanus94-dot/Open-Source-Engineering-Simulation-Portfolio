# OpenSCAD - Parametric Electronics Enclosure

Fully parametric box + lid: set PCB size and the whole design (posts, vents, cut-outs, lid lip) updates.
Print-ready STL via `make`.

```bash
make            # box.stl, lid.stl
make preview.png
openscad -D pcb_l=100 -D pcb_w=60 enclosure.scad   # customise
```
Print tips: 0.2 mm layers, 3 perimeters, no supports needed (vents bridge).

## Skills demonstrated
CSG modelling, modules, parametric design, design-for-3D-printing, command-line export / Makefile.
