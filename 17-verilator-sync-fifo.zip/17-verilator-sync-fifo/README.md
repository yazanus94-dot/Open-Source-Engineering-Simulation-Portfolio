# Verilator - Synchronous FIFO with C++ Reference-Model Testbench

RTL FIFO (parameterised, Gray-free pointer-wrap full/empty) verified by a **C++ testbench** driven by Verilator:
bursty random traffic (forces full and empty conditions), a `std::queue` scoreboard, flag checking, and VCD tracing.
Verilator compiles the RTL to C++ so 200k cycles run in well under a second.

```bash
make lint   # Verilator -Wall lint
make run    # build, simulate, print PASS/FAIL
gtkwave fifo.vcd
```
Extensions: SystemVerilog assertions (`--assert`), coverage (`--coverage` + `verilator_coverage`), async FIFO with Gray-coded pointers, cocotb integration.

## Skills demonstrated
Verilator flow (lint, C++ harness, tracing), RTL design, scoreboarding, directed-random verification.
