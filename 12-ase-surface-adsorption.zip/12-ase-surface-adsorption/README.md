# ASE - Equation of State and Adsorption on Cu(111)

End-to-end atomistic workflow built from ASE primitives: bulk EOS fit (Birch-Murnaghan), slab construction,
constraints, BFGS relaxation, adsorption-site screening, trajectory output and visualisation.
Uses the EMT potential so it runs in seconds; the calculator line can be replaced by GPAW/QE/VASP/LAMMPS
(`ase.calculators.espresso`, `ase.calculators.lammpsrun`) without touching the workflow.

```bash
pip install -r requirements.txt
python workflow.py
ase gui Au_fcc.traj
```
Caveat to mention in interviews: EMT is a toy-quality model; energies are for workflow demonstration. Re-run with DFT for meaningful values.

## Skills demonstrated
Atoms/calculators/optimizers, constraints, surface builders, EOS, calculator-agnostic design.
