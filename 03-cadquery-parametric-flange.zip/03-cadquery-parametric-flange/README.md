# CadQuery - Parametric Pipe Flange with Unit Tests

Code-CAD flange (bolt circle, hub, bore) driven by parameters; exports STEP/STL and computes mass.
A pytest suite verifies the solid volume against the analytical formula - CAD treated as testable software.

```bash
pip install -r requirements.txt
python flange.py --od 160 --bolts 8
pytest -q
```
View `flange.step` in FreeCAD / `cq-editor`; slice `flange.stl` for 3D printing.

## Skills demonstrated
Parametric design, selectors, boolean ops, STEP/STL export, test-driven CAD.
