# PyBaMM - Lithium-Ion Battery Simulation Study

Uses the Chen2020 (LG M50) parameter set.
1. C-rate sweep (0.2-2C): rate-dependent capacity,
2. SPM vs SPMe vs DFN: accuracy vs. computational cost,
3. Ambient temperature effect with a lumped thermal model,
4. 20 cycles with CC-CV charging and SEI-driven capacity fade.

```bash
pip install -r requirements.txt
python simulate.py
```
Outputs `results.png`, `capacity_fade.png`. Extensions: parameter fitting to your own cycler data, drive-cycle experiments, pack-level models.

## Skills demonstrated
Electrochemical modelling, experiment definition, solver use, model-fidelity trade-offs, degradation modelling.
