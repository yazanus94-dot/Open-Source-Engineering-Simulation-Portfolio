# SU2 - Transonic Euler Flow over a NACA0012

Mesh generated programmatically (Gmsh API, size fields, SU2 export), solved with SU2 (JST, implicit Euler,
adaptive CFL). Expected: shock on the upper surface at roughly 0.6c at M = 0.8, alpha = 1.25 deg.

```bash
pip install gmsh numpy pandas matplotlib
./run.sh
```
Outputs: `history.csv` (convergence, CL/CD), `flow.vtu` (ParaView), `cp.png`.
Extensions: grid convergence (Richardson), RANS (`SOLVER=RANS`, SA model), adjoint shape optimisation.

## Skills demonstrated
CFD set-up, compressible flow, boundary markers, convergence monitoring, mesh sizing, scripted workflow.
