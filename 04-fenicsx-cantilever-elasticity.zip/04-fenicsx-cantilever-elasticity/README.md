# FEniCSx - Cantilever Beam under Self-Weight (3D Linear Elasticity)

Variational formulation in UFL, Dirichlet BC on the clamped face, direct LU solve, mesh refinement study,
and **verification vs. Euler-Bernoulli** (delta = rho g A L^4 / 8EI).
Linear hexahedra (Q1) lock in bending, so expect under-prediction that shrinks with refinement - a useful
discussion point (try quadratic elements: `("Lagrange", 2, (3,))`).

```bash
conda create -n fenicsx -c conda-forge fenics-dolfinx mpich pyvista
conda activate fenicsx
python cantilever.py
```
Output: `displacement.xdmf` (ParaView).

## Skills demonstrated
Weak forms, function spaces, boundary conditions, solver configuration, verification & convergence studies.
