# CalculiX - Cantilever Beam Verification

Scripted pre-processing (structured hex mesh + `.inp` generated in Python), static linear solve with `ccx`,
and verification against Euler-Bernoulli and **Timoshenko** (shear-corrected) beam theory.
`C3D8I` (incompatible-mode) elements avoid shear locking that plain `C3D8` shows in bending.

```bash
./run.sh                # change mesh: python make_inp.py 80 8 8
```
Extensions: `C3D20R` elements, modal analysis (`*FREQUENCY`), contact, thermo-mechanical coupling (`*COUPLED TEMPERATURE-DISPLACEMENT`).

## Skills demonstrated
`.inp` keyword structure, element-type selection, BCs & loads, result parsing, verification against analytics.
