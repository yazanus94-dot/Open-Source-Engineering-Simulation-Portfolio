# KiCad - NE555 Astable LED Blinker (Schematic-as-Code to PCB)

Complete small hardware project flow: design calculations (`design_calc.py`: ~1.05 Hz, ~50 % duty),
schematic captured as code with **SKiDL** -> KiCad netlist -> PCB layout in Pcbnew, BOM, and a layout/release checklist.

```bash
pip install skidl
make                      # prints design numbers, writes 555_blinker.net
# then follow docs/layout_checklist.md in KiCad (Import Netlist, route, DRC, export Gerbers)
```
**To complete this project (important):** do the PCB layout in KiCad yourself and commit the `.kicad_*` files plus
screenshots of the schematic, PCB, and 3D view into this folder - recruiters look for those.

## Skills demonstrated
Circuit design & calculation, symbol/footprint assignment, ERC/DRC discipline, BOM, fabrication outputs.
