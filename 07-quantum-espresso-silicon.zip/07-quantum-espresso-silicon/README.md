# Quantum ESPRESSO - Silicon: Convergence, Lattice Constant, Band Structure

DFT (LDA, norm-conserving PP) workflow for diamond-Si:
1. Convergence of total energy vs. `ecutwfc` and k-mesh,
2. Equilibrium lattice constant from an E(a) scan (reference: 5.431 A),
3. Band structure along L-G-X-W-G and the indirect gap (LDA underestimates: ~0.5 eV vs. 1.12 eV exp.).

```bash
# put Si.pz-vbc.UPF in ./pseudo
NP=4 ./run.sh
```
Notes: the quick parabolic fit can be replaced with a Birch-Murnaghan EOS (`ase.eos`). The k-path here is
simplified; for publication-grade paths use `pymatgen.symmetry.bandstructure.HighSymmKpath`.

## Skills demonstrated
pw.x/bands.x input design, convergence testing, post-processing with Python, MPI execution, physical sanity checks.
