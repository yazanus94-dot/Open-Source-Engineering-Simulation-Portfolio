# ngspice - Analog Circuit Analysis (AC, Transient, Nonlinear)

- `rlc_lowpass.cir`: 2nd-order low-pass, AC sweep + step response, `.meas` for peak and -3 dB point.
- `rc_diode_clipper.cir`: nonlinear diode clipper with RC filter (SPICE `.model`).
- `plot.py`: plotting plus **analytic cross-check** (f0 = 5.03 kHz, Q = 2 -> +6 dB peak).

```bash
./run.sh
```
## Skills demonstrated
Netlist writing, `.control` scripting, AC/TRAN analysis, `.meas`, device models, verifying simulation against theory.
