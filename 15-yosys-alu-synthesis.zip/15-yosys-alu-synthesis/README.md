# Yosys - 8-bit ALU: RTL Synthesis and Equivalence Checking

Synthesises a behavioural ALU to a generic gate library (`abc`), reports cell counts, and **formally proves**
gate-level == RTL with `equiv_make / equiv_simple / equiv_induct`. The same self-checking testbench
(20k random vectors, iverilog) is run on RTL and the synthesised netlist.

```bash
./run.sh
```
Extensions: map to a real standard-cell library (`abc -liberty sky130_fd_sc_hd__tt_025C_1v80.lib`),
pipeline the ALU and compare timing with OpenSTA, push through OpenLane for GDS.

## Skills demonstrated
Verilog, Yosys script flow (proc/opt/synth/abc), netlist export, formal equivalence, simulation-based verification.
