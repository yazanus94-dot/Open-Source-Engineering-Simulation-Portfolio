# Elmer FEM - Steady Heat Conduction in an Aluminium Plate with a Cooled Hole

**Physics:** Steady heat conduction, k = 237 W/mK. Left edge 100 C, right edge 20 C,
convective cooling (h = 25 W/m2K) on the hole boundary.
**Workflow:** Gmsh (OpenCASCADE geometry + physical groups) -> `ElmerGrid` -> `ElmerSolver` -> ParaView.

## Run
```bash
./run.sh
```
## Extensions
- Transient run (`Simulation Type = Transient`, add time stepping).
- Mesh convergence on total heat flow (`Calculate Loads`).
- Compare against 1D analytic solution without the hole.

## Skills demonstrated
SIF file structure, boundary-condition mapping via physical groups, iterative linear solvers, FEM pre/post workflow.
