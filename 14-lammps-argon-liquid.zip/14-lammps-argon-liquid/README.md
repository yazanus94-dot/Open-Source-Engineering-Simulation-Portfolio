# LAMMPS - Liquid Argon: Structure and Diffusion

864-atom Lennard-Jones argon (real units), melt -> NVT equilibration -> 0.5 ns production.
Analysis: radial distribution function g(r) and self-diffusion coefficient from the Einstein relation (MSD slope / 6).

```bash
NP=4 ./run.sh
```
Check: density should be ~1.4 g/cm3 (use `thermo` output; adjust lattice constant or switch to `fix npt`
at 1 atm for a rigorous state point). Compare D with experiment (~2e-9 m2/s).
Extensions: Green-Kubo viscosity, solid-liquid melting curve, `compute stress/atom`, GPU/KOKKOS runs.

## Skills demonstrated
LAMMPS input scripting, thermostats, computes/fixes, equilibration protocol, statistical post-processing.
