# pymatgen - Crystal Structure Analysis Pipeline

Builds Si (diamond), NaCl (rock-salt) and Cu (fcc) from space-group + Wyckoff data, then computes
space group, primitive cell, density, coordination (CrystalNN), simulated Cu-Ka powder XRD, writes CIFs and a JSON report.
Includes a supercell + vacancy example and unit tests.

```bash
pip install -r requirements.txt
python analyze.py && pytest -q
```
Extension: query the Materials Project (`mp-api`) and compare computed vs. database structures; generate VASP/QE input sets.

## Skills demonstrated
Structure objects, symmetry analysis, local environments, diffraction, I/O (CIF/JSON), testing.
