# Gmsh - Refined Mesh of a Plate with a Hole (Python API)

Geometry via OpenCASCADE booleans, physical groups for boundary conditions, `Distance`+`Threshold` size fields
for refinement towards the stress concentration, Frontal-Delaunay algorithm, optional 2nd-order elements and a
mesh-quality histogram. Output `plate.msh` is directly usable by FEniCSx (`dolfinx.io.gmshio`), Elmer (`ElmerGrid 14`),
or CalculiX/SU2 via converters.

```bash
pip install -r requirements.txt
python mesh_plate.py        # linear triangles
python mesh_plate.py 2      # quadratic triangles
```
## Skills demonstrated
Geometry kernel, physical groups, size fields, mesh quality metrics, scripted/reproducible meshing.
