# OpenFOAM - Lid-Driven Cavity (icoFoam)

**Objective:** Incompressible laminar flow in a 2D square cavity with a moving lid; Re = 10.
**Solver:** `icoFoam` (transient PISO, Euler time stepping, linear Gauss schemes).
**Mesh:** `blockMesh`, 40x40 cells, 1 cell in the empty (2D) direction.

## Run
```bash
./Allrun        # blockMesh -> checkMesh -> icoFoam
paraFoam        # or open case.foam in ParaView
./Allclean
```
## Things to check / extend
- Courant number in `log.icoFoam` (must stay < 1; here Co ~ 0.2).
- Mesh-independence study: change `(40 40 1)` to `(20 20 1)` and `(80 80 1)` and compare centerline velocity.
- Validate against Ghia et al. (1982) data; raise nu^-1 to Re = 100/400 (use finer mesh).

## Skills demonstrated
Case structure (0/constant/system), blockMesh, boundary conditions, PISO, numerical schemes, post-processing in ParaView.
