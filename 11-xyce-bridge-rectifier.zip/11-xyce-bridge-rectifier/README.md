# Xyce - Bridge Rectifier Ripple Study (Parametric `.STEP` Sweep)

Parallel-capable SPICE (Sandia Xyce): 50 Hz full-wave rectifier, diode `.MODEL`, `.PARAM`,
`.STEP` sweep over filter capacitance, CSV output, ripple extraction and comparison with the analytic estimate
dV = I/(2 f C).

```bash
./run.sh
```
Note: Xyce names stepped outputs `bridge.csv`, `bridge.csv.FREQ...` depending on version - `analyze.py` globs them.
Extension: Monte-Carlo (`.SAMPLING`), temperature sweep, transformer + diode reverse-recovery study.

## Skills demonstrated
Xyce netlist syntax (differs from ngspice), `.PARAM/.STEP/.PRINT`, nonlinear device models, results post-processing.
